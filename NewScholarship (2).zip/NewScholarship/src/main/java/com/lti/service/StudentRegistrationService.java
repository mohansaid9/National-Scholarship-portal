package com.lti.service;

import com.lti.dto.StudentRegistrationDTO;

public interface StudentRegistrationService {
	public String registerStudent(StudentRegistrationDTO studentRegistrationDTO);      //transient class//add==registerStudent


}
