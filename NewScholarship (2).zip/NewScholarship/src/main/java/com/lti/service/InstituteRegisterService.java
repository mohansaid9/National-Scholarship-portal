package com.lti.service;

import com.lti.dto.InstituteRegisterDTO;


public interface InstituteRegisterService {
	public String registerInstitute(InstituteRegisterDTO instituteRegisterDTO);      //transient class//add==registerStudent

}
