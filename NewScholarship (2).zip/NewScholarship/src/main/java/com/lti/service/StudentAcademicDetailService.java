package com.lti.service;

import com.lti.pojo.StudentAcademicDetail;

public interface StudentAcademicDetailService {
	public String addStudentAcademicDetail(StudentAcademicDetail academicObj);    ////used from dao but return type changed
}
