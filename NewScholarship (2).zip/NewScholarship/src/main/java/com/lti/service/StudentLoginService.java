package com.lti.service;



public interface StudentLoginService {
	boolean  isStudentPresentService(String aadhar,String password);
	

}
