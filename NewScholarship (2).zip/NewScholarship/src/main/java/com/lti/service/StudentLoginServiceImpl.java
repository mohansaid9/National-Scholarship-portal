package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.StudentBasicDetailDAO;
import com.lti.dao.StudentLoginDAO;
import com.lti.pojo.StudentBasicDetail;

@Service
public class StudentLoginServiceImpl implements StudentLoginService {
@Autowired
StudentLoginDAO sbdObj;

	@Override
	public boolean isStudentPresentService(String aadhar, String password) {
		boolean res= sbdObj.isPresent(aadhar,password);
		System.out.println("it reached service impl");
	
		return res;
	}
		
	
	
	}
			