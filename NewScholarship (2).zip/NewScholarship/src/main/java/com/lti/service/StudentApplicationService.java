package com.lti.service;

import com.lti.dto.ScholarshipApplicationDTO;

public interface StudentApplicationService {
	public String addScholarshipApplication(ScholarshipApplicationDTO scholarshipApplicationDto);
	public String testStu(ScholarshipApplicationDTO scholarshipApplicationDto);
	public String registerStudent(ScholarshipApplicationDTO scholarshipApplicationDto);//transient class//add==registerStudent
}
