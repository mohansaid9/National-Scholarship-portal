package com.lti.dao;

import java.util.List;

import com.lti.pojo.StudentDisabilityDetail;

public interface StudentDisabilityDetailDAO {
public void deleteDisabilityDetail(String aadhar);
public void addStudentDisabilityDetail(StudentDisabilityDetail disabilityObj);   	
	public void updateDisabilityDetail(String aadhar, int percentageOfDisability, String typeOfDisability);
	
	public StudentDisabilityDetail getDisabilityDetail(String aadhar);
	
	public List< StudentDisabilityDetail> getAllDisabilityDetail ();
}
