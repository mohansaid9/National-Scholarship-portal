package com.lti.dao;

import java.util.List;

import com.lti.pojo.StudentStatusDetail;

public interface StudentStatusDetailDAO {
	public void addStudentStatusDetail(StudentStatusDetail StudentStatusObj);         
	public void deleteStudentStatusDetail(String aadhar);
	public void updateStudentStatusDetail(String aadhar,String instituteApprovalStatus,String ministryApprovalStatus,int sanctionedAmount,String stateNodalOfficerStatus);
	public List<StudentStatusDetail> getallStudentStatusDetail();
	public StudentStatusDetail getStudentStatusDetail(String aadhar);
}
