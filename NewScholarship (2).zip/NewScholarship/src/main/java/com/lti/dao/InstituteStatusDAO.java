package com.lti.dao;

import java.util.List;

import com.lti.pojo.InstituteStatus;

public interface InstituteStatusDAO {
	public void addInstituteStatus(InstituteStatus InstituteStatusObj);  
	public void deleteInstituteStatus(String instituteCode);
	public void updateInstituteStatus(String instituteCode,String minsitryApprovalStatus,String stateNodalOfficerStatus);
	public List<InstituteStatus> getallInstituteStatus();
	public InstituteStatus getStatus(String instituteCode);

}
