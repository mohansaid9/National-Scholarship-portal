package com.lti.dao;


import com.lti.pojo.StudentBasicDetail;

public interface StudentRegistrationDAO {
	public void	insertIntoStudentRegistrationForm(StudentBasicDetail studentRegisterObj);
}
