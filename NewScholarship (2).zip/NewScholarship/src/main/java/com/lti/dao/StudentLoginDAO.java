package com.lti.dao;

import com.lti.pojo.StudentBasicDetail;

public interface StudentLoginDAO {

	boolean isPresent(String aadhar, String Password);
}
