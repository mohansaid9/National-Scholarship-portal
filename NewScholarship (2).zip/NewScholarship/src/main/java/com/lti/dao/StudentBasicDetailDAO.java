package com.lti.dao;

import java.util.List;

import com.lti.pojo.StudentBasicDetail;

public interface StudentBasicDetailDAO {

	public void addStudentBasicDetail(StudentBasicDetail addStudentBasicDetailObj);    //used to add                                 
	public void deleteStudentBasicDetail(int aadhar);
	public void updateStudentBasicDetail(StudentBasicDetail updateStudentBasicDetailObj);
	
	public StudentBasicDetail getStudentBasicDetail(String aadhar);
	public List<StudentBasicDetail> getAll();
	public StudentBasicDetail login(String aadhar);
	
}
