package com.lti.dao;

import java.util.List;

import com.lti.pojo.StudentBankDetail;

public interface StudentBankDetailDAO {
	public void addStudentBankDetail(StudentBankDetail bankObj);    
	
	public void deleteBankDetail(String accountNo);
	
	public void updateBankDetail(String accountNo,String bankName,String bankIfsc);
	
	public StudentBankDetail getBank(String accountNo);
	
	public List< StudentBankDetail> getAllBankDetail ();
}
