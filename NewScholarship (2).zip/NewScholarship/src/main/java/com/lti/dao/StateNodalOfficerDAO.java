package com.lti.dao;

import java.util.List;

import com.lti.pojo.StateNodalOfficer;

public interface StateNodalOfficerDAO {
	public List<StateNodalOfficer> getAllStateNodalOfficer();
	public void addStateNodalOfficer(StateNodalOfficer stateObj);    
	public void deleteStateNodalOfficer(int stateNodalOfficerId);
	public void updateStateNodalOfficer(int stateNodalOfficerId,String stateNodalOfficerName,String stateNodalOfficerPassword,String state);
	public StateNodalOfficer getState(int stateNodalOfficerId);
	


}
