package com.lti.dao;

import com.lti.pojo.InstituteDetail;

public interface InstituteRegistrationDAO {
	public void	insertIntoInstituteRegistrationForm(InstituteDetail instituteRegisterObj);
}
