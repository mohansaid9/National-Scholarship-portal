package com.lti.dao;

import com.lti.pojo.Address;
import com.lti.pojo.StudentAcademicDetail;
import com.lti.pojo.StudentBasicDetail;
import com.lti.pojo.StudentDisabilityDetail;
import com.lti.pojo.StudentDocumentDetail;
import com.lti.pojo.StudentFeeDetail;
import com.lti.pojo.StudentPersonalDetail;

public interface StudentApplySchemeDAO {
	public void	insertIntoStudentApplicationFormViaAadhar(Address address,
			StudentAcademicDetail studentAcademicDetail, 
			StudentDisabilityDetail studentDisabilityDetail,
			StudentDocumentDetail studentDocumentDetail,
			StudentPersonalDetail studentPersonalDetail,
			StudentFeeDetail studentFeeDetail);
}
