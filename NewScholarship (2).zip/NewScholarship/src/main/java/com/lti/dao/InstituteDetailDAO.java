package com.lti.dao;

import java.util.List;

import com.lti.pojo.Address;
import com.lti.pojo.InstituteDetail;

public interface InstituteDetailDAO {

	public void addInstitute(InstituteDetail addObj);                                     
	public void deleteAddress(int instituteCode);
	public void updateAddress(InstituteDetail updateObj);
	public InstituteDetail getInstituteDetail(String instituteCode);
	
	public List< InstituteDetail> getAllInstituteDetail ();
	
}
