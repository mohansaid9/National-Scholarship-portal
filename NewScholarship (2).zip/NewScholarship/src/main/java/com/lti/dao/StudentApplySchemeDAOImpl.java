package com.lti.dao;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.pojo.Address;
import com.lti.pojo.StudentAcademicDetail;
import com.lti.pojo.StudentBasicDetail;
import com.lti.pojo.StudentDisabilityDetail;
import com.lti.pojo.StudentDocumentDetail;
import com.lti.pojo.StudentFeeDetail;
import com.lti.pojo.StudentPersonalDetail;
@Repository
public class StudentApplySchemeDAOImpl implements StudentApplySchemeDAO {
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	@Transactional
	public void insertIntoStudentApplicationFormViaAadhar(Address address, StudentAcademicDetail studentAcademicDetail,
			StudentDisabilityDetail studentDisabilityDetail, StudentDocumentDetail studentDocumentDetail,
			StudentPersonalDetail studentPersonalDetail, StudentFeeDetail studentFeeDetail
			) {
		StudentBasicDetail studentBasicDetails = new StudentBasicDetail();
		
		Set<Address> addressSet = new HashSet<>();
		Address address2 = new Address();
		address2.setStudentBasicDetail(studentBasicDetails);
		
		addressSet.add(address2);//
		
		studentBasicDetails.setAddresses( addressSet);
		studentBasicDetails.setStudentAcademicDetail(studentAcademicDetail);
		studentBasicDetails.setStudentPersonalDetail(studentPersonalDetail);
		studentBasicDetails.setStudentFeeDetail(studentFeeDetail);
		studentBasicDetails.setStudentDocumentDetail(studentDocumentDetail);
		studentBasicDetails.setStudentDisabilityDetail(studentDisabilityDetail);
		studentBasicDetails.setStudentAcademicDetail(studentAcademicDetail);
		
		entityManager.merge(studentBasicDetails);
		

	}

}
