import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institute-login',
  templateUrl: './institute-login.component.html',
  styleUrls: ['./institute-login.component.css']
})
export class InstituteLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
