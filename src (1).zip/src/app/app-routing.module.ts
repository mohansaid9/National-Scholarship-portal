import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { from } from 'rxjs';
import {HomeComponent} from './home/home.component';
import {InstituteLoginComponent} from './institute-login/institute-login.component';
import {InstituteRegistrationComponent} from './institute-registration/institute-registration.component';
import {StudentLoginComponent} from './student-login/student-login.component';
import {StudentRegistrationComponent} from './student-registration/student-registration.component';
import {StudentApplyingForSchemeComponent } from './student-applying-for-scheme/student-applying-for-scheme.component'

const routes: Routes = [
  {
    component:HomeComponent,
    path: 'home'
  },
  {
    component:StudentLoginComponent,
    path: 'studentlogin'
  },
  {
    component:InstituteLoginComponent,
    path: 'institutelogin'
  },
  {
    component:InstituteRegistrationComponent,
    path: 'instituteregistration'
  },
  
  {
    component:StudentRegistrationComponent,
    path: 'studentregistration'
  },
  {
    component:StudentApplyingForSchemeComponent,
    path: 'studentapplyingforscheme'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
