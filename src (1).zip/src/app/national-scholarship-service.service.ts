import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {ApplyForScheme} from 'src/ApplyForScheme';
import {StudentRegistrationDetail} from 'src/StudentRegistrationDetail';
import{StudentLogin} from 'src/StudentLogin';
import { Observable } from 'rxjs';
 

@Injectable({
  providedIn: 'root'
})
export class NationalScholarshipServiceService {

  baseUrl: string = 'http://localhost:8080/';
  constructor(private myhttp:HttpClient) { }



  addNewStudent(newStudent: StudentRegistrationDetail): Observable<StudentRegistrationDetail>//
  {
    return this.myhttp.post<StudentRegistrationDetail>(this.baseUrl+"addFarmer",newStudent);
  }
 /* authenticate(customer: ): Observable<Customer> {
    return this.http.post<Customer>(this.baseUrl + "customers/login",customer);
}*/

  studentLogin(slogin: StudentLogin): Observable<StudentLogin>
  
  {
    console.log('service is called'+slogin)
      return this.myhttp.post<any>(this.baseUrl+"studentLogin",slogin);
  }

 /* applyForScheme(newApplyForScheme: ApplyForScheme): Observable<ApplyForScheme>
  {
    return this.myhttp.post<ApplyForScheme>(this.baseUrl+"addSellRequest",newApplyForScheme);
  }*/

 }
