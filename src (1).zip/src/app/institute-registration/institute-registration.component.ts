import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institute-registration',
  templateUrl: './institute-registration.component.html',
  styleUrls: ['./institute-registration.component.css']
})
export class InstituteRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
