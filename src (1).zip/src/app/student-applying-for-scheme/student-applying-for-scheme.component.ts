import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-applying-for-scheme',
  templateUrl: './student-applying-for-scheme.component.html',
  styleUrls: ['./student-applying-for-scheme.component.css']
})
export class StudentApplyingForSchemeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
