import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentApplyingForSchemeComponent } from './student-applying-for-scheme.component';

describe('StudentApplyingForSchemeComponent', () => {
  let component: StudentApplyingForSchemeComponent;
  let fixture: ComponentFixture<StudentApplyingForSchemeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentApplyingForSchemeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentApplyingForSchemeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
