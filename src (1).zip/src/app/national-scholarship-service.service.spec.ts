import { TestBed } from '@angular/core/testing';

import { NationalScholarshipServiceService } from './national-scholarship-service.service';

describe('NationalScholarshipServiceService', () => {
  let service: NationalScholarshipServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NationalScholarshipServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
