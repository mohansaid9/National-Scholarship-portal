import { Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from "@angular/router";
import { from } from 'rxjs';
import {StudentLogin} from 'src/StudentLogin';
import {NationalScholarshipServiceService} from '../national-scholarship-service.service'

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit {
 // aadhar:any;
 //password:any;
 // message:any;
  studlog = new StudentLogin();
  //studlog.aadhar = this.aadhar;
  //studlog.password = this.password;
  constructor(private sserve: NationalScholarshipServiceService, private router: Router) {}
    onSubmit()
  {
   
    this.sserve.studentLogin(this.studlog).subscribe(
      user=>{
        //alert(JSON.stringify(user))

        if(user)
        {
          console.log('Success');
          alert('Login Successful..')
          
        }
        else
        {
          alert('Wrong Credentials... Try again');
          // this.message=user.message
          // alert(this.message)
          console.log('errors');
        }
      }
    )
  }



  ngOnInit(): void {
  }

}
