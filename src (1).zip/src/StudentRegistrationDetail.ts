export class StudentRegistrationDetail {
    aadhar: string;
    age: number;
    dateOfBirth: Date;
    emailId: string;
    fathersName: string;
    gender: string;
    mobile: string;
    mothersName: string;
    name: string;
    password: string;
    instituteCode: string;
    blockOrTaluka: string;
    city: string;
    dist: string;
    houseNumber: string;
    line1: string;
    line2: string;
    pincode : number;
    state: string;
    streetNumber: string;
    //bank
    accountNo: string;
    bankIfsc: string;
    bankName: string
}