export class ApplyForScheme {
    //student academic
    aadhar: string;
    boardName: string;
    passingYear: number;
    percentage: number;
    rollNo: string;
    standard: number;
    presentYear: number;
    modeOfStudy: string;
    presentCourse: string;
    prevousYear: number;
    previousCourse: string;
    previousCoursePercent: number;
    //student basic
    age: number;
    dateOfBirth: Date;
    emailId: string;
    fathersName: string;
    gender: string;
    mobile: string;
    mothersName: string;
    name: string;
    instituteCode: string;

    //student disability
    percentageOfDisability: number;
    typeOfDisability: string;
    //student doc
    bankPassbookFrontPage: string;
    casteOrIncomeCertificate: string;
    domicileCertificate: string;
    feeRecieptOfCurrentYear: string;
    aadhaarCard: string;

    instituteBonafiedCertificate: string;

    instituteIdCard: string;
    ninthMarksheet: string;
    previousYearMarksheet: string;
    studentPhotograph: string;
    tenthMarksheet: string;
    twelfthMarksheet: string;
    //student fee
    admissionFee: number;
    otherFee: number;
    tuitionFee: number;
    //address


    //student personal
    category: string;
    chooseScheme: string;
    community: string;
    familyIncome: number;
    fathersProfession: string;
    isDisabled: string;
    maritalStatus: string;
    mothersProfession: string;
    religion: string;


    //instituteDetail


    admissionStartedYear: number;


    affilUniversityBoardName: string;


    affilUniversityState: string;

    diseCode: string;


    instituteCategory: string;


    instituteName: string;

    instituteType: string;

    location: string;


    mobileNumber: string;


    principalName: string;

    telephone: string;

    Password: string;


    addressId: number;


    blockOrTaluka: string;

    city: string;

    dist: string;


    houseNumber: string;


    line1: string;


    line2: string;

    pincode: number;

    state: string;
}