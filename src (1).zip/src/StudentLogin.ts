export class StudentLogin {
    aadhar: string;
    password: string;
}